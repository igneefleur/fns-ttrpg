/* Pont d20 — s'exécute dans le MONDE PRINCIPAL de la page Roll20 (là où vit
 * window.d20 / window.Campaign, invisible depuis un content-script isolé). Injecté
 * par content-roll20.js dans la frame du haut via <script src=web_accessible>.
 *
 * Rôle : lire, créer et mettre à jour les Attributes « hxh_* » d'un personnage, à la
 * demande de l'iframe du créateur (qui poste des messages vers window.top). Modèle
 * client confirmé par VTTES / Beyond20 / roll20-character-exporter-importer :
 *   Campaign.characters.get(id).attribs -> collection Backbone
 *     .models                 -> [{ get('name'|'current'|'max'), attributes, save() }]
 *     .create()               -> nouvel attribut (on remplit .attributes puis .save())
 *   attr.save({current,max})  -> persiste (Firebase) et synchronise à tous les joueurs.
 *
 * Écritures THROTTLÉES : Roll20 déconnecte / perd des écritures sur des rafales
 * (importateurs tiers insèrent un « Rest Time »). On écrit un attribut à la fois,
 * espacés, en file séquentielle.
 */
(function () {
  "use strict";
  var PREFIX = "hxh_";
  var WRITE_DELAY = 60;   // ms entre deux écritures d'attribut

  function str(v) { return v == null ? "" : String(v); }
  function campaign() { return window.Campaign || (window.d20 && window.d20.Campaign) || null; }
  function getChar(id) {
    var c = campaign();
    return (c && c.characters && c.characters.get) ? c.characters.get(id) : null;
  }
  function models(ch) { return (ch && ch.attribs && ch.attribs.models) || []; }
  function attrVal(m, key) { return m.get ? m.get(key) : (m.attributes && m.attributes[key]); }
  function findAttr(ch, name) {
    var ms = models(ch);
    for (var i = 0; i < ms.length; i++) if (attrVal(ms[i], "name") === name) return ms[i];
    return null;
  }

  function readAll(id) {
    var ch = getChar(id), out = {};
    models(ch).forEach(function (m) {
      var n = attrVal(m, "name");
      if (typeof n === "string" && n.indexOf(PREFIX) === 0) {
        out[n] = { current: str(attrVal(m, "current")), max: str(attrVal(m, "max")) };
      }
    });
    return out;
  }

  // Écriture SILENCIEUSE — indispensable quand la fiche du perso est OUVERTE.
  // Un attribut modifié déclenche sinon onAttribChange -> updateSheetValues de Roll20,
  // qui plante (« u.childWindow.d20 is undefined ») -> la fiche charge à l'infini.
  // Deux précautions :
  //  - set(..., {silent:true}) (et NON .attributes=) : met à jour le suivi de changement
  //    Backbone, si bien que l'écho Firebase de notre écriture voit une valeur IDENTIQUE
  //    -> aucun événement change -> Roll20 ne rafraîchit pas la fiche -> pas de crash ;
  //  - save(null, {silent:true}) persiste dans Firebase (le sync ne dépend pas de silent).
  function writeOne(ch, name, v) {
    var data = { name: name, current: str(v && v.current), max: str(v && v.max) };
    var m = findAttr(ch, name);
    if (!m) {
      m = ch.attribs.create(data, { silent: true });
      if (m && m.save) m.save(null, { silent: true });
      return;
    }
    if (m.set) m.set(data, { silent: true });
    else { m.attributes = m.attributes || {}; m.attributes.name = data.name; m.attributes.current = data.current; m.attributes.max = data.max; }
    if (m.save) m.save(null, { silent: true });
  }

  var queue = [], busy = false;
  function enqueue(id, attrs) { queue.push({ id: id, attrs: attrs || {} }); pump(); }
  function pump() {
    if (busy) return;
    var job = queue.shift();
    if (!job) return;
    busy = true;
    var ch = getChar(job.id);
    var names = Object.keys(job.attrs), i = 0;
    function step() {
      if (!ch || i >= names.length) {
        // PAS de ch.view.render() ici : re-render déclencherait la mise à jour de fiche
        // de Roll20 (celle qui plante). Les attributs sont persistés via Firebase ;
        // l'onglet Attributes se met à jour de lui-même (au pire à la réouverture).
        busy = false;
        setTimeout(pump, 0);
        return;
      }
      var name = names[i++];
      try { writeOne(ch, name, job.attrs[name]); } catch (e) {}
      setTimeout(step, WRITE_DELAY);   // throttle
    }
    step();
  }

  function reply(ev, msg) { msg.ns = "hxh"; try { ev.source.postMessage(msg, "*"); } catch (e) {} }

  // Écouteur PASSIF : n'agit QUE sur nos messages (ns:"hxh" + charId), qui ne sont
  // émis que sur interaction (ouverture de l'onglet Fiche HxH). On NE poste RIEN de
  // spontané au chargement — Roll20 ouvre ses fiches via postMessage, un message
  // inattendu casserait son gestionnaire. Tout est en try/catch pour ne jamais
  // laisser une exception remonter dans le contexte de Roll20.
  window.addEventListener("message", function (ev) {
    try {
      var d = ev.data;
      if (!d || d.ns !== "hxh" || !d.charId) return;
      if (d.type === "has-sheet") {
        var a = readAll(d.charId);
        reply(ev, { type: "has-sheet-result", charId: d.charId, exists: !!a[PREFIX + "version"] });
      } else if (d.type === "load") {
        reply(ev, { type: "hydrate", charId: d.charId, attrs: readAll(d.charId) });
      } else if (d.type === "save") {
        enqueue(d.charId, d.attrs);
      }
    } catch (e) {}
  }, false);
})();
