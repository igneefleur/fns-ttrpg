/* Correspondance fiche JJK <-> Attributes Roll20 (natifs par valeur).
 *
 * Le créateur (jjk-creation.js, réutilisé tel quel) travaille sur un objet
 * `state` imbriqué. Roll20 stocke des Attributes plats {name, current, max}.
 * Ce module fait la traduction, DANS LES DEUX SENS et SANS PERTE :
 *   - stateToAttrs(state, card) : décompose l'état en attributs Roll20.
 *   - attrsToState(attrs)       : reconstruit l'état depuis les attributs.
 *
 * TOUS les attributs produits commencent par « jjk_ ». Trois familles :
 *   - SOURCE DE VÉRITÉ : `jjk_state` porte l'état ENTIER en JSON. C'est lui
 *     qu'on relit pour reconstruire la fiche : il ne dérive JAMAIS quand
 *     jjk-creation.js gagne un champ. attrsToState le préfère à tout le reste ;
 *     la reconstruction champ par champ n'est qu'un repli.
 *   - NATIFS (repli + macros) : un attribut par valeur/collection.
 *   - MIROIR (écrits seulement si `card` fourni) : valeurs DÉRIVÉES pour les
 *     macros et barres de jetons Roll20 — caractéristiques TOTALES
 *     (@{perso|jjk_body}), PV courant/max, vitesse. Non relus (recalculés
 *     par le créateur).
 *
 * Logique PURE, sans API navigateur : testable en node, chargée telle quelle
 * dans l'iframe du créateur.
 */
(function (root) {
  "use strict";

  var PREFIX = "jjk_";

  // champ d'état scalaire -> [suffixe, type] (n = nombre, s = chaîne libre)
  var SCALARS = [
    ["name", "nom", "s"], ["age", "age", "s"], ["genre", "genre", "s"],
    ["portrait", "portrait", "s"], ["defaut", "defaut", "s"],
    ["background", "background", "s"], ["notes", "notes", "s"],
    ["inventaire", "inventaire", "s"], ["de", "de", "s"],
    ["xpTotal", "xp_total", "n"], ["narration", "narration", "n"],
    ["sansLimite", "sans_limite", "b"],
    ["v", "version", "n"]
  ];

  // champ d'état collection (objet/tableau) -> suffixe (stocké en JSON)
  var COLLECTIONS = [
    ["qualites", "qualites"], ["avantages", "avantages"],
    ["caracsBase", "caracs_base"], ["caracsXp", "caracs_xp"],
    ["comps", "competences"], ["customComps", "comp_perso"],
    ["armes", "armes"], ["armures", "armures"]
  ];

  // état par défaut (miroir de blank() de jjk-creation.js ; sert de socle à la
  // reconstruction : un attribut absent laisse la valeur par défaut).
  function blank() {
    return {
      v: 1,
      name: "", portrait: "", age: "", genre: "",
      defaut: "", qualites: ["", ""], background: "", notes: "",
      avantages: [], sansLimite: false,
      caracsBase: { Mind: 0, Body: 0, Prestance: 0 },
      caracsXp: { Mind: 0, Body: 0, Prestance: 0 },
      xpTotal: 500,
      comps: {}, customComps: [],
      pv: null, narration: 3,
      armes: [], armures: [], inventaire: "",
      de: "1d100"
    };
  }

  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }
  function str(v) { return v == null ? "" : String(v); }

  // { fullAttrName -> {current, max} }
  function stateToAttrs(state, card) {
    state = state || blank();
    var out = {};
    function put(suffix, current, max) {
      out[PREFIX + suffix] = { current: str(current), max: str(max == null ? "" : max) };
    }

    // ROUND-TRIP COMPLET : l'état entier en un attribut, source de vérité.
    put("state", JSON.stringify(state));

    SCALARS.forEach(function (d) {
      var v = state[d[0]];
      put(d[1], d[2] === "b" ? (v ? 1 : 0) : v);
    });
    COLLECTIONS.forEach(function (d) {
      put(d[1], JSON.stringify(state[d[0]] == null ? blank()[d[0]] : state[d[0]]));
    });
    // PV courant nullable : conservé à l'exact (null = « au maximum »)
    put("etat_courant", JSON.stringify({ pv: state.pv == null ? null : state.pv }));

    // ---- miroir dérivé (macros / barres de jetons), seulement si la carte est fournie ----
    if (card) {
      var cc = card.caracs || {};
      put("mind", cc.Mind);
      put("body", cc.Body);
      put("prestance", cc.Prestance);
      var cb = card.combat || {};
      put("pv", cb.pv == null ? cb.pvMax : cb.pv, cb.pvMax);   // barre de jeton : PV courant / max
      put("vitesse", cb.vitesse);
    }
    return out;
  }

  // attrs : { fullAttrName -> {current, max} } ou { fullAttrName -> current }.
  // Reconstruit l'état (round-trip). Les attributs miroir sont ignorés.
  function attrsToState(attrs) {
    attrs = attrs || {};
    function cur(suffix) {
      var a = attrs[PREFIX + suffix];
      if (a == null) return undefined;
      return (typeof a === "object" && a !== null) ? a.current : a;
    }
    // Priorité : l'état complet round-trip (jjk_state). Repli sur la
    // reconstruction champ par champ pour des fiches partielles
    // (jjk-creation.js re-normalise dans tous les cas).
    var full = cur("state");
    if (full !== undefined && full !== "") {
      try { var fs = JSON.parse(full); if (fs && typeof fs === "object") return fs; } catch (e) {}
    }
    var s = blank();

    SCALARS.forEach(function (d) {
      var v = cur(d[1]);
      if (v === undefined) return;
      if (d[2] === "n") { if (v !== "" && isFinite(parseFloat(v))) s[d[0]] = num(v); }
      else if (d[2] === "b") s[d[0]] = String(v) === "1" || String(v) === "true";
      else s[d[0]] = str(v);
    });
    COLLECTIONS.forEach(function (d) {
      var v = cur(d[1]);
      if (v === undefined || v === "") return;
      try { var o = JSON.parse(v); if (o != null) s[d[0]] = o; } catch (e) {}
    });
    var ec = cur("etat_courant");
    if (ec !== undefined && ec !== "") {
      try {
        var o = JSON.parse(ec);
        s.pv = (o && o.pv != null) ? o.pv : null;
      } catch (e) {}
    }
    return s;
  }

  function isJjkAttr(name) { return typeof name === "string" && name.indexOf(PREFIX) === 0; }
  // une fiche JJK existe si l'attribut de version est présent
  function hasSheet(names) {
    if (!names) return false;
    var list = Array.isArray(names) ? names : Object.keys(names);
    return list.indexOf(PREFIX + "version") >= 0;
  }

  var api = {
    PREFIX: PREFIX,
    stateToAttrs: stateToAttrs,
    attrsToState: attrsToState,
    isJjkAttr: isJjkAttr,
    hasSheet: hasSheet,
    blank: blank
  };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.JjkAttrMap = api;
})(typeof window !== "undefined" ? window : this);
